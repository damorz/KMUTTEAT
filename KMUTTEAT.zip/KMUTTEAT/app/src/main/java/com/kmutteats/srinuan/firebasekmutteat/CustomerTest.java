package com.kmutteats.srinuan.firebasekmutteat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CustomerTest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_test);
    }
}
